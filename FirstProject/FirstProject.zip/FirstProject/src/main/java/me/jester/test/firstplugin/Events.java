package me.jester.test.firstplugin;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class Events implements Listener {

    private CustomItems ci = new CustomItems();
    @EventHandler
    public void onPunch(PlayerInteractEvent event){
        Player player = event.getPlayer();
        ci.giveItems(player);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        Inventory pInventory = player.getInventory();
        ItemStack item = new ItemStack(Material.DIAMOND, 1);

        if (!player.isOnGround()) {
            player.sendMessage(ChatColor.RED + "You are moving");
            pInventory.addItem(item);
        }
    }
}
