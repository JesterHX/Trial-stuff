package me.jester.test.firstplugin;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemBreakEvent;

public class BreakBlock implements Listener {

    @EventHandler
    public void onBlockBreak(PlayerItemBreakEvent event){
        System.out.println(2);
    }
}
