package me.jester.test.firstplugin;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Locale;

public class Healing implements Listener {
    @EventHandler
    public void onMine(PlayerInteractEvent event) {
        Action action = event.getAction();
        Player player = event.getPlayer();
        Block block = event.getClickedBlock();

        if (action.equals(Action.LEFT_CLICK_BLOCK)) {
            if (block.getType().equals(Material.DIAMOND_ORE)) {
                if (player.getHealth() != 20){
                    player.setHealth(player.getHealth() + 1);
                    player.sendMessage("§aYou have been healed for:§c+1 Health");
                }else {
                    player.sendMessage(ChatColor.RED + "You are already at full Health");
                }
            } else {
                player.sendMessage(ChatColor.GOLD + "You clicked: " + ChatColor.RED + block.getType().toString().toUpperCase(Locale.ROOT));
            }

        }
    }
}