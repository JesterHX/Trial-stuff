package me.jester.test.firstplugin;

import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public final class FirstPlugin extends JavaPlugin {
    public static FirstPlugin instance;
    @Override
    public void onEnable() {
        instance = this;
        System.out.println(ChatColor.GREEN + "----------\nHello\n----------");
        getServer().getPluginManager().registerEvents(new Events(),this);
        getServer().getPluginManager().registerEvents(new BreakBlock(), this);
        getServer().getPluginManager().registerEvents(new Healing(), this);
        getServer().getPluginManager().registerEvents(new Breakage(), this);
        loadConfig();
    }

    @Override
    public void onDisable() {
        System.out.println(ChatColor.RED + "----------\nGoodbye\n----------");
    }

    public void loadConfig(){
        getConfig().options().copyDefaults(true);
        saveConfig();
    }

}