package me.jester.test.firstplugin;

import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

public class CustomItems implements Listener {
    public void giveItems(Player player){
        ItemStack item = new ItemStack(Material.DIAMOND_AXE, 1);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName("§bAxe of Jeller" );
        ArrayList<String> lore = new ArrayList<>();
        lore.add("§fThe chae muddafookin taylors Axe");
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);

        player.getInventory().addItem(item);


    }
    public void customRecipe(){

        ShapedRecipe JellerAxe = new ShapedRecipe(item);

    }
}
