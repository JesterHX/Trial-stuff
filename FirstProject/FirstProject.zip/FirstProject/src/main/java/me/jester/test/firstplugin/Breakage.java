package me.jester.test.firstplugin;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public class Breakage implements Listener {

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        Player player = event.getPlayer();
        Location location = block.getLocation();

        player.sendMessage(ChatColor.GOLD + "You broke:" + ChatColor.AQUA + block.getType().toString().toUpperCase());
        player.sendMessage(ChatColor.DARK_GREEN + "Location:");
        player.sendMessage(ChatColor.BLUE + "World: " + ChatColor.WHITE + location.getWorld().getName());
        player.sendMessage(ChatColor.BLUE + "X: " + ChatColor.WHITE + location.getBlockX());
        player.sendMessage(ChatColor.BLUE + "Y: " + ChatColor.WHITE + location.getBlockY());
        player.sendMessage(ChatColor.BLUE + "Z: " + ChatColor.WHITE + location.getBlockZ());
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        Block block = event.getBlock();
        Player player = event.getPlayer();
        Location location = block.getLocation();

        player.sendMessage(ChatColor.GOLD + "You placed:" + ChatColor.AQUA + block.getType().toString().toUpperCase());
        player.sendMessage(ChatColor.DARK_GREEN + "Location:");
        player.sendMessage(ChatColor.BLUE + "World: " + ChatColor.WHITE + location.getWorld().getName());
        player.sendMessage(ChatColor.BLUE + "X: " + ChatColor.WHITE + location.getBlockX());
        player.sendMessage(ChatColor.BLUE + "Y: " + ChatColor.WHITE + location.getBlockY());
        player.sendMessage(ChatColor.BLUE + "Z: " + ChatColor.WHITE + location.getBlockZ());



        if (block.getType().equals(Material.TNT)) {
           Utils.broadcast("&6" + player.getName() + " placed: &b" + block.getType().toString().toUpperCase());

        } else if (block.getType().equals(Material.BEDROCK)){
            Utils.broadcast("&6" + player.getName() + " placed: &b" + block.getType().toString().toUpperCase());
        }
    }
}