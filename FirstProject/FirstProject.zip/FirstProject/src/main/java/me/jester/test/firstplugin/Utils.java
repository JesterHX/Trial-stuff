package me.jester.test.firstplugin;


public class Utils {
    public static void broadcast(String message){
        FirstPlugin.instance.getServer().broadcastMessage(message.replace("&", "§"));
    }
}
